import multiprocessing as mp
from detection_and_tracking import PlateDetector
from text_extraction import OCRProcesor

class ImageProcessor:
    def __init__(self):
        self.cropped_images_queue = mp.Queue()

    def process_cropped_image(self):
        ocr_processor = OCRProcesor()
        
        while True:
            cropped_image = self.cropped_images_queue.get()
            if cropped_image is None:  
                break
            
            ocr_results = ocr_processor.process_image(cropped_image)
            
            if ocr_results:  # Check if results are not empty
                for text, confidence in ocr_results:
                    print(f"OCR Results for Image '{text}', Confidence: {confidence}")

    def start(self):
        ocr_process = mp.Process(target=self.process_cropped_image)
        ocr_process.start()

        detector = PlateDetector(save_cropped_images=True)
        detector.start_detection(self.cropped_images_queue.put)

        # Signal termination
        self.cropped_images_queue.put(None)
        
        ocr_process.join()

def main():
    image_processor = ImageProcessor()
    image_processor.start()

if __name__ == "__main__":
    main()