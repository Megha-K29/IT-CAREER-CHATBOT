import cv2
import csv
from paddleocr import PaddleOCR
import os

class OCRProcesor:
    def __init__(self):
        self.ocr = PaddleOCR(use_angle_cls=True, lang='en', use_space_char=True)
        self.processed_texts = set()  #to track processed texts

    def process_image(self, image):
        if image is None:
            print("Image not loaded properly")
            return

        height, width = image.shape[:2]
        scale_factor = 2
        scaled_image = cv2.resize(image, (width * scale_factor, height * scale_factor))
        gray_image = cv2.cvtColor(scaled_image, cv2.COLOR_BGR2GRAY)
        blurred_image = cv2.GaussianBlur(gray_image, (5, 5), 0)

        results = self.ocr.ocr(blurred_image, cls=True)

        for result in results:
            if result:
                for line in result:
                    text = line[1][0]
                    confidence = line[1][1]

                    # Check if text has already been processed
                    if text not in self.processed_texts:
                        self.processed_texts.add(text)  
                        self.save_to_csv(text, confidence)

    def save_to_csv(self, text, confidence, filename='extracted_texts.csv'):
        file_exists = os.path.isfile(filename)
        with open(filename, mode='a', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            if not file_exists:
                writer.writerow(['Extracted Text', 'Confidence Score'])

            writer.writerow([text, confidence])  
        
        print(f"Data saved to {filename}: '{text}' with confidence {confidence}.")
        
        
         