import cv2
from ultralytics import YOLO
import os

class PlateDetector:
    def __init__(self, model_path='best.pt', video_source='car.mp4', output_directory='output', save_cropped_images=False):
        self.model = YOLO(model_path)
        self.video = video_source
        self.output = output_directory
        self.frame_count = 0  
        self.detection_counter = {}  
        self.last_detections = {} 
        self.plate_id_counter = 0  
        self.save_cropped_images = save_cropped_images  

        os.makedirs(self.output, exist_ok=True)

    def is_same_plate(self, box1, box2, threshold=50):
        return (abs(box1[0] - box2[0]) < threshold and abs(box1[1] - box2[1]) < threshold) or \
               (abs(box1[2] - box2[2]) < threshold and abs(box1[3] - box2[3]) < threshold)

    def start_detection(self, process_cropped_image):
        cap = cv2.VideoCapture(self.video)  
        
        if not cap.isOpened():
            print("Error: Could not open the video stream")
            return

        while True:
            ret, frame = cap.read()
            if not ret:
                print("Error: Frame is None or end of video reached")
                break
            
            results = self.model.track(frame, stream=True) 
                
            for result in results:
                boxes = result.boxes  
                    
                for box in boxes:
                    b = box.xyxy[0]  
                    class_name = self.model.names[int(box.cls)] 

                    if class_name == 'License Plate': 
                        xmin, ymin, xmax, ymax = map(int, b[:4])  
                        current_box = (xmin, ymin, xmax, ymax)
                        found_plate_id = None
                        
                        
                        # Check against last detections to see if this is a previously detected plate
                        for existing_plate_id, last_box in self.last_detections.items():
                            if self.is_same_plate(current_box, last_box):
                                found_plate_id = existing_plate_id
                                break
        
                        # If it's a new plate detection
                        if found_plate_id is None:
                            found_plate_id = f"plate_{self.plate_id_counter}"
                            self.plate_id_counter += 1 
                            self.detection_counter[found_plate_id] = 0

                        # Update last known position of this plate
                        self.last_detections[found_plate_id] = current_box
                        self.detection_counter[found_plate_id] += 1

                       
                        frame = cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)

                        # Checking if it is valid
                        if self.detection_counter[found_plate_id] == 30:
                            cropped_image = frame[ymin:ymax, xmin:xmax]
                            process_cropped_image(cropped_image)  # Passing cropped image
                            
                            # Save full frame to output directory
                            full_frame_filename = os.path.join(self.output, f"full_frame_{self.frame_count}.jpg")
                            cv2.imwrite(full_frame_filename, frame)

                            if self.save_cropped_images:
                                cropped_image_filename = os.path.join(self.output, f"cropped_license_plate_{self.frame_count}.jpg")
                                cv2.imwrite(cropped_image_filename, cropped_image)

            self.frame_count += 1
        
        cap.release() 
        
        
        
