import numpy as np
import cv2
import shutil
import os
class LabelAssigner:
    def __init__(self, img_dir, lbl_dir, aug_dir):
        self.img_dir = img_dir
        self.lbl_dir = lbl_dir
        self.aug_dir = aug_dir
        
    def get_label(self, filename):
        fname = os.path.splitext(filename)
        label_file_name = f"{fname[0]}.txt"
        lbl_path = os.path.join(self.lbl_dir, label_file_name)
        if os.path.exists(lbl_path):
            with open(lbl_path) as lbl_file:
                return lbl_file.read().strip(), label_file_name
        else:
            print("Label File is Missing:", filename)
            shutil.move(os.path.join(self.img_dir, filename), os.path.join(self.background_images_path, filename))
            return None
        
    def create_fog_overlay(self, image, fog_density=0.5):
        # Create a random noise image
        noise = np.random.rand(*image.shape) * 255
        noise = noise.astype(np.uint8)
        
        # Apply Gaussian blur to make fog
        fog_overlay = cv2.GaussianBlur(noise, (21, 21), 0)
        
        # Blend the original image with the fog overlay
        fog_image = cv2.addWeighted(image, 1 - fog_density, fog_overlay, fog_density, 0)
        
        return fog_image
    
    def process_images(self):
        # Making the directory for saving the augmented images
        aug_dir_images_path = os.path.join(self.aug_dir, "Images")
        os.makedirs(aug_dir_images_path, exist_ok=True)

        # Making the directory for saving the augmented labels
        aug_dir_labels_path = os.path.join(self.aug_dir, "Labels")
        os.makedirs(aug_dir_labels_path, exist_ok=True)

        # Making the directory for saving the background images
        self.background_images_path = os.path.join(self.aug_dir, "Background")
        os.makedirs(self.background_images_path, exist_ok=True)
        
        for img_name in os.listdir(self.img_dir):
            if img_name.lower().endswith(('.jpg', '.jpeg', '.png')):
                img_path = os.path.join(self.img_dir, img_name)
                image = cv2.imread(img_path)

                # Create a regular fog overlay
                fog_aug_image = self.create_fog_overlay(image, fog_density=0.5)

                # Create a heavy fog overlay
                fog_heavy_aug_image = self.create_fog_overlay(image, fog_density=0.7)

                # Saving the fog augmented images
                fog_aug_path = os.path.join(aug_dir_images_path, "fog_" + img_name)
                fog_heavy_aug_path = os.path.join(aug_dir_images_path, "fog_heavy_" + img_name)
                cv2.imwrite(fog_aug_path, fog_aug_image)
                cv2.imwrite(fog_heavy_aug_path, fog_heavy_aug_image)
                
                # Get the label for the image
                label, label_file_name = self.get_label(img_name)
                if label:
                    # Save the label to the augmented labels directory
                    fog_aug_label_path = os.path.join(aug_dir_labels_path, "fog_" + label_file_name)
                    fog_heavy_aug_label_path = os.path.join(aug_dir_labels_path, "fog_heavy_" + label_file_name)

                    # Save the label files
                    with open(fog_aug_label_path,'w') as f:
                        f.write(label)
                    with open(fog_heavy_aug_label_path,'w') as f:
                        f.write(label)

if __name__ == "__main__":
    img_dir = r'raw\images'
    lbl_dir = r"raw\labels"
    aug_dir = r"augmenteddata"
    label_assigner = LabelAssigner(img_dir, lbl_dir, aug_dir)
    label_assigner.process_images()