import os
import albumentations as A
import cv2
import shutil

class LabelAssigner:
    def __init__(self, img_dir, lbl_dir, aug_dir):
        self.img_dir = img_dir
        self.lbl_dir = lbl_dir
        self.aug_dir = aug_dir
        
    def get_label(self,filename):
        fname = os.path.splitext(filename)
        label_file_name = f"{fname[0]}.txt"
        lbl_path = os.path.join(self.lbl_dir, label_file_name)
        if os.path.exists(lbl_path):
            with open(lbl_path) as lbl_file:
                return lbl_file.read().strip(), label_file_name
        else:
            print("Label File is Missing:", filename)
            shutil.move(os.path.join(self.img_dir, filename), os.path.join(self.background_images_path, filename))
            return None
        
    def apply_rain(self, image):
        rain_drizzle_lower_brightness = A.Compose([
            A.RandomRain(always_apply=True, p=1.0, slant_lower=-10, slant_upper=10, 
                         drop_length=20, drop_width=1, drop_color=(150, 150, 150), 
                         blur_value=1, brightness_coefficient=0.17, rain_type='drizzle'),
        ])
        rain_heavy_lower_brightness = A.Compose([
            A.RandomRain(always_apply=True, p=1.0, slant_lower=-10, slant_upper=10, 
                         drop_length=13, drop_width=1, drop_color=(150, 150, 150), 
                         blur_value=3, brightness_coefficient=0.17, rain_type='heavy'),
        ])
        rain_drizzle = A.Compose([
            A.RandomRain(always_apply=True, p=1.0, slant_lower=-10, slant_upper=10, 
                         drop_length=20, drop_width=1, drop_color=(150, 150, 150), 
                         blur_value=1, brightness_coefficient=1.0, rain_type='drizzle'),  
        ])
        rain_heavy = A.Compose([
            A.RandomRain(always_apply=True, p=1.0, slant_lower=-10, slant_upper=10, 
                         drop_length=13, drop_width=1, drop_color=(150, 150, 150), 
                         blur_value=3, brightness_coefficient=1.0, rain_type='heavy'),  
        ])
        
        rain_drizzle_lower_brightness_aug = rain_drizzle_lower_brightness(image=image)
        rain_heavy_lower_brightness_aug = rain_heavy_lower_brightness(image=image)
        rain_drizzle_aug = rain_drizzle(image=image)
        rain_heavy_aug = rain_heavy(image=image)
        
        return rain_drizzle_lower_brightness_aug['image'], rain_heavy_lower_brightness_aug['image'], rain_drizzle_aug['image'], rain_heavy_aug['image']
        
    def process_images(self):
        # Making the directory for saving the augmented images
        aug_dir_images_path = os.path.join(self.aug_dir, "Images")
        os.makedirs(aug_dir_images_path, exist_ok=True)

        # Making the directory for saving the augmented labels
        aug_dir_labels_path = os.path.join(self.aug_dir, "Labels")
        os.makedirs(aug_dir_labels_path, exist_ok=True)

        # Making the directory for saving the background images
        self.background_images_path = os.path.join(self.aug_dir, "Background")
        os.makedirs(self.background_images_path, exist_ok=True)
        
        for img_name in os.listdir(self.img_dir):
            if img_name.lower().endswith(('.jpg', '.jpeg', '.png')):
                img_path = os.path.join(self.img_dir, img_name)
                image = cv2.imread(img_path)
                
                # if image is None:
                #     print(f"Failed to load image: {img_path}")
                #     continue
                
                rain_drizzle_lower_brightness_aug, rain_heavy_lower_brightness_aug, rain_drizzle_aug, rain_heavy_aug = self.apply_rain(image)

                # Saving the rain drizzle lower brightness augmented image
                rain_drizzle_lower_brightness_path = os.path.join(aug_dir_images_path, "rain_drizzle_lower_brightness_"+ img_name)
                cv2.imwrite(rain_drizzle_lower_brightness_path, rain_drizzle_lower_brightness_aug)
                
                # Saving the rain heavy lower brightness augmented image
                rain_heavy_lower_brightness_path = os.path.join(aug_dir_images_path, "rain_heavy_lower_brightness_"+ img_name)
                cv2.imwrite(rain_heavy_lower_brightness_path, rain_heavy_lower_brightness_aug)
                
                # Saving the rain drizzle augmented image
                rain_drizzle_aug_path = os.path.join(aug_dir_images_path, "rain_drizzle_"+ img_name)
                cv2.imwrite(rain_drizzle_aug_path, rain_drizzle_aug)
                
                # Saving the rain heavy augmented image
                rain_heavy_aug_path = os.path.join(aug_dir_images_path, "rain_heavy_"+ img_name)
                cv2.imwrite(rain_heavy_aug_path, rain_heavy_aug)
                
                # Get the label for the image
                label, label_file_name = self.get_label(img_name)
                if label:
                    # Save the label to the augmented labels directory
                    rain_drizzle_lower_brightness_label_path = os.path.join(aug_dir_labels_path, "rain_drizzle_lower_brightness_"+ label_file_name)
                    rain_heavy_lower_brightness_label_path = os.path.join(aug_dir_labels_path, "rain_heavy_lower_brightness_"+ label_file_name)
                    rain_drizzle_aug_label_path = os.path.join(aug_dir_labels_path, "rain_drizzle_"+ label_file_name)
                    rain_heavy_aug_label_path = os.path.join(aug_dir_labels_path, "rain_heavy_"+ label_file_name)
                    
                    # Save the label files
                    with open(rain_drizzle_lower_brightness_label_path,'w') as f:
                        f.write(label)
                    with open(rain_heavy_lower_brightness_label_path,'w') as f:
                        f.write(label)
                    with open(rain_drizzle_aug_label_path,'w') as f:
                        f.write(label)
                    with open(rain_heavy_aug_label_path,'w') as f:
                        f.write(label)

if __name__ == "__main__":
    img_dir = r'images'
    lbl_dir = r"labels"
    aug_dir = r"augmenteddata"
    label_assigner = LabelAssigner(img_dir, lbl_dir, aug_dir)
    label_assigner.process_images()