import os
from PIL import Image
import shutil

class LabelAssigner:
    def __init__(self, img_dir, lbl_dir,aug_dir):
        self.img_dir = img_dir
        self.lbl_dir = lbl_dir
        self.aug_dir = aug_dir

    def get_label(self, filename):
        fname = os.path.splitext(filename)
        label_file_name = f"{fname[0]}.txt"
        lbl_path = os.path.join(self.lbl_dir, label_file_name)
        if os.path.exists(lbl_path):
            with open(lbl_path) as lbl_file:
                return lbl_file.read().strip(), label_file_name
        else:
            print("Label File is Missing:", filename)
            shutil.move(os.path.join(self.img_dir,filename),os.path.join(self.background_images_path,filename))
            return None

    def flip_label(self, label_content,label_file_name):
        flipped_labels = []
        for line in label_content.splitlines():
            points = line.split()
            class_id = points[0]
            x_center = points[1]
            y_center = points[2]
            width = points[3]
            height = points[4]

            # Calculating x_center for the flipped image
            new_x_center = 1 - float(x_center)
            flipped_labels.append(f"{class_id} {new_x_center:.6f} {y_center} {width} {height}")

        label_directory_path=os.path.join(self.aug_dir,"Labels")
        label_file_path = os.path.join(label_directory_path, "horizontal_flip_"+label_file_name)
        with open(label_file_path, 'w') as lbl_file:
            lbl_file.write("\n".join(flipped_labels))

    def process_images(self):

        #Making the directory for saving the augmented images.
        aug_dir_images_path=os.path.join(self.aug_dir,"Images")
        os.makedirs(aug_dir_images_path, exist_ok=True)

        #Making the directory for saving the augmented labels.
        aug_dir_labels_path=os.path.join(self.aug_dir,"Labels")
        os.makedirs(aug_dir_labels_path, exist_ok=True)

        #Making the directory for saving the background images.
        self.background_images_path=os.path.join(self.aug_dir,"Background")
        os.makedirs(self.background_images_path, exist_ok=True)

        for file in os.listdir(self.img_dir):
            if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                
                try:
                    #Calling the get_label function for fetching the label file.
                    label_content,label_file_name=self.get_label(file)
                    if self.get_label(file) is None:
                        continue
                    #Calling the flip label function to flip the labels.
                    self.flip_label(label_content,label_file_name)
                    #Opening the image.
                    img = Image.open(os.path.join(self.img_dir, file))
                    #Flipping the image.
                    h_flipped_img=img.transpose(Image.FLIP_LEFT_RIGHT)
                    #Saving the image into the specified directory with the specific name.
                    h_flipped_img.save(os.path.join(aug_dir_images_path,f"horizontal_flip_{file}"))
                except:
                    continue

if __name__ == "__main__":
    img_dir=r'images'
    lbl_dir=r"labels"
    aug_dir=r"augmenteddata"
    label_assigner = LabelAssigner(img_dir,lbl_dir,aug_dir)
    label_assigner.process_images()
    
