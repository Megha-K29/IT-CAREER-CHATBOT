import os
import cv2
import shutil
import numpy as np

class LabelAssigner:
    def __init__(self, img_dir, lbl_dir, aug_dir):
        self.img_dir = img_dir
        self.lbl_dir = lbl_dir
        self.aug_dir = aug_dir
        
    def get_label(self, filename):
        fname = os.path.splitext(filename)
        label_file_name = f"{fname[0]}.txt"
        lbl_path = os.path.join(self.lbl_dir, label_file_name)
        if os.path.exists(lbl_path):
            with open(lbl_path) as lbl_file:
                lines = lbl_file.readlines()
                boxes = []
                for line in lines:
                    parts = line.strip().split()
                    if len(parts) == 5:  
                        class_id, x_center, y_center, width, height = map(float, parts)
                        boxes.append((x_center, y_center, width, height)) 
                return lines, label_file_name, boxes
        else:
            print("Label File is Missing:", filename)
            shutil.move(os.path.join(self.img_dir, filename), os.path.join(self.background_images_path, filename))
            return None

    def zoom_out_image(self, image, zoom_out_scale):
        # Zoom out the original image
        zoomed_out = cv2.resize(image,(image.shape[1] // zoom_out_scale, image.shape[0] // zoom_out_scale))
        return zoomed_out

    def select_farthest_grid_cell(self, zoomed_out_image, annotated_boxes):
        height, width,_ = zoomed_out_image.shape
        grid_size = (height // 5, width // 5)

        # Calculate the center of the zoomed-out image
        img_center_x = width // 2
        img_center_y = height // 2

        # Find the grid cell far from all annotated boxes
        max_distance = 0
        selected_cell_start_row = 0
        selected_cell_start_col = 0

        for grid_row in range(5):
            for grid_col in range(5):
                start_row = grid_row * grid_size[0]
                start_col = grid_col * grid_size[1]
                end_row = start_row + grid_size[0]
                end_col = start_col + grid_size[1]

                # Calculate the center of the current grid cell
                cell_center_x = (start_col + end_col) // 2
                cell_center_y = (start_row + end_row) // 2

                # Calculate the distance from the grid cell center to the image center
                distance = ((cell_center_x - img_center_x) ** 2 + (cell_center_y - img_center_y) ** 2) ** 0.5

                # Check if this grid cell is farthest from all annotated boxes
                for (x_center, y_center, box_width, box_height) in annotated_boxes:
                    box_x1 = int((x_center - box_width / 2) * (width / 2))  
                    box_y1 = int((y_center - box_height / 2) * (height / 2))  
                    box_x2 = int((x_center + box_width / 2) * (width / 2))  
                    box_y2 = int((y_center + box_height / 2) * (height / 2))  

                    # Check if the grid cell is inside the bounding box
                    if not (end_col < box_x1 or start_col > box_x2 or end_row < box_y1 or start_row > box_y2):
                        distance = 0  
                        break

                if distance > max_distance:
                    max_distance = distance
                    selected_cell_start_row = start_row
                    selected_cell_start_col = start_col

        # Extract the selected grid cell
        selected_grid = zoomed_out_image[selected_cell_start_row:selected_cell_start_row + grid_size[0],
                                         selected_cell_start_col:selected_cell_start_col + grid_size[1]]

        return selected_grid
 
    def pad_with_grid_cell(self, zoomed_out_image, selected_grid):
        # Get the dimensions of the zoomed-out image
        img_height, img_width, _ = zoomed_out_image.shape
        
        # Define the target size for the padded image
        target_size = 640

        # Calculate the padding needed for each side
        pad_top = (target_size - img_height) // 2
        pad_bottom = target_size - img_height - pad_top
        pad_left = (target_size - img_width) // 2
        pad_right = target_size - img_width - pad_left

        # Create a new padded image filled with the selected grid cell
        padded_image = np.zeros((target_size, target_size, 3), dtype=np.uint8)

        # Resize the selected grid cell to be square
        square_size = max(pad_left + pad_right + img_width,
                          pad_top + pad_bottom + img_height) // max(1,(pad_left + pad_right + img_width)//img_width)
        
        square_grid = cv2.resize(selected_grid, (square_size,square_size))

        # Fill the entire padded image with the square grid
        for i in range(0, target_size, square_size):
            for j in range(0, target_size, square_size):
                padded_image[i:i + square_size, j:j + square_size] = square_grid

        # Place the zoomed-out image in the center of the padded image
        padded_image[pad_top:pad_top + img_height, pad_left:pad_left + img_width] = zoomed_out_image

        return padded_image

    def process_images(self):
        # Making the directory for saving the augmented images
        aug_dir_images_path = os.path.join(self.aug_dir, "Images")
        os.makedirs(aug_dir_images_path, exist_ok=True)

        # Making the directory for saving the augmented labels
        aug_dir_labels_path = os.path.join(self.aug_dir, "Labels")
        os.makedirs(aug_dir_labels_path, exist_ok=True)

        # Making the directory for saving background images
        self.background_images_path = os.path.join(self.aug_dir, "Background")
        os.makedirs(self.background_images_path, exist_ok=True)
        
        for img_name in os.listdir(self.img_dir):
            if img_name.lower().endswith(('.jpg', '.jpeg', '.png')):
                img_path = os.path.join(self.img_dir, img_name)
                image = cv2.imread(img_path)
                
                zoom_out_scale = 4  # Adjust this value for more or less zoom
                zoomed_out_image = self.zoom_out_image(image, zoom_out_scale)

                label_lines, label_file_name, annotated_boxes = self.get_label(img_name)

                if annotated_boxes:
                    selected_grid = self.select_farthest_grid_cell(zoomed_out_image, annotated_boxes)

                    final_image = self.pad_with_grid_cell(zoomed_out_image, selected_grid)

                    # Adjust bounding box coordinates for padded image
                    height_final_img, width_final_img,_= final_image.shape
                    
                    pad_top   =(height_final_img - zoomed_out_image.shape[0]) // 2 
                    pad_left   =(width_final_img - zoomed_out_image.shape[1]) // 2 

                    adjusted_boxes= []
                    
                    for (x_center,y_center,width,height) in annotated_boxes:
                        x_center_scaled   =(x_center / zoom_out_scale) 
                        y_center_scaled   =(y_center / zoom_out_scale)
                        width_scaled      =(width / zoom_out_scale)
                        height_scaled     =(height / zoom_out_scale)

                        x_center_adjusted =(x_center_scaled + pad_left / width_final_img)
                        y_center_adjusted =(y_center_scaled + pad_top / height_final_img)

                        adjusted_boxes.append((x_center_adjusted,y_center_adjusted,width_scaled,height_scaled))

                    # Create new label lines with adjusted boxes                    
                    new_label_lines=[]
                    
                    for class_id in range(len(adjusted_boxes)):
                        x_center,y_center,width,height=adjusted_boxes[class_id]
                        new_label_lines.append(f"{class_id} {x_center} {y_center} {width} {height}\n")

                    
                    final_image_path=os.path.join(aug_dir_images_path,"zoomed_out_" + img_name)
                    cv2.imwrite(final_image_path ,final_image)

                    final_label_path=os.path.join(aug_dir_labels_path,"zoomed_out_" + label_file_name)
                    
                    with open(final_label_path,'w') as f:
                        f.writelines(new_label_lines)

if __name__ == "__main__":
    img_dir= r'raw\rawfogcombined\images'  
    lbl_dir= r"raw\rawfogcombined\labels"  
    aug_dir= r"augmenteddata\rawfogcombined"  
    
    label_assigner= LabelAssigner(img_dir,lbl_dir ,aug_dir)
    label_assigner.process_images()